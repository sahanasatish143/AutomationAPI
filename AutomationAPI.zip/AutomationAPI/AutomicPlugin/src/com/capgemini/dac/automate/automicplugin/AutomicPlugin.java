/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.automicplugin;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import com.uc4.api.StatisticSearchItem;
import com.uc4.api.TaskPromptSetName;
import com.uc4.api.UC4ObjectName;
import com.uc4.api.objects.PromptElement;
import com.uc4.communication.Connection;
import com.uc4.communication.TimeoutException;
import com.uc4.communication.requests.CreateSession;
import com.uc4.communication.requests.ExecuteObject;
import com.uc4.communication.requests.GenericStatistics;
import com.uc4.communication.requests.SubmitPrompt;
import com.uc4.communication.requests.TaskPromptSetContent;
import com.uc4.communication.requests.TaskPromptSetNames;
import com.capgemini.dac.automate.automationplugin.AutomationPlugin;

/**
 * This class represents the plugin for  Automic engine. It implements
 * AutomationPlugin which is the contract for all automation plugins.
 * 
 * @author Shaik Abdul Sharukh
 */
public class AutomicPlugin implements AutomationPlugin
{
  private static final Logger logger = Logger.getLogger(AutomicPlugin.class.getName());
  /**
   * Default constructor
   */
  public AutomicPlugin()
  {
  }

  /*
   * (non-Javadoc)
   * @see com.capgemini.dac.automate.automationplugin.AutomationPlugin#getAutomationEngineName()
   */
  @Override
  public String getAutomationEngineName()
  {
    return "automic";
  }

  /*
   * (non-Javadoc)
   * @see com.capgemini.dac.automate.automationplugin.AutomationPlugin#startAutomation(java.lang.String, java.lang.String, java.util.Map)
   * 
   * parameters is a map of key value pairs describing parameters for the
   * automation. Initially it gets login into the automic depending upon the
   * environment and customer identifier with the generic credentials
   * pulled out from the configuration file and it executes the automation
   * depending upon the automationName present in the Map of key value pairs.
   * 
   * @see Automation name should be part of parameters
   */
  @Override
  public String startAutomation(String environment, String customerIdentifier, Map<String, String> parameters)
  {
    String automationName = parameters.get("automationName");
    CreateSession logonRet = null;
    Map<String, String> connectionConfiguration = null;

    try
    {
      connectionConfiguration = getConnectionConfiguration();
    } 
    catch (IOException e2)
    {
      e2.printStackTrace();
    }

    Connection con = null;
    String server = connectionConfiguration.get("SERVER_" + customerIdentifier + "_" + environment);
    String password = connectionConfiguration.get("PASSWORD_" + customerIdentifier + "_" + environment);
    String port = connectionConfiguration.get("PORT_" + customerIdentifier + "_" + environment);
    String client = connectionConfiguration.get("CLIENT_" + customerIdentifier + "_" + environment);
    String user = connectionConfiguration.get("USER_" + customerIdentifier + "_" + environment);
    String dept = connectionConfiguration.get("DEPT_" + customerIdentifier + "_" + environment);
    String language = connectionConfiguration.get("LANGUAGE_" + customerIdentifier + "_" + environment);
      
    System.out.println(server);
    System.out.println(port);
    System.out.println(client);
    System.out.println(user);
    System.out.println(dept);
    System.out.println(language);
    logger.info("Connection parameters are:"+server+port+client+user+dept+language);

    // we are not going to open a connection at every single call.
    try 
    {
      // opening the connection...
      // getting values of server and port from config file
      con = Connection.open(server, Integer.parseInt(port));
      logonRet = con.login(Integer.parseInt(client), user, dept, password, language.charAt(0));
    }
    catch (NumberFormatException | IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    if (!logonRet.isLoginSuccessful())
      throw new IllegalArgumentException(logonRet.getMessageBox().getText());

    // passing the automationaName that has to be run
    // into the UC4ObjectName and then executing the automation
    UC4ObjectName testCase = new UC4ObjectName(automationName);
    ExecuteObject exec = new ExecuteObject(testCase);
    try 
    {
      con.sendRequestAndWait(exec);
    } 
    catch (TimeoutException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    } 
    catch (IOException e) 
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    if (exec.getMessageBox() != null)
    {
      throw new RuntimeException(exec.getMessageBox().getText());
    }

    // get the unique runId of the automation that has run
    String runId = String.valueOf(exec.getRunID());
    System.out.println("runId=" + runId);
    logger.info("runId="+ runId);
    TaskPromptSetNames names = new TaskPromptSetNames(exec.getRunID());
    try 
    {
      con.sendRequestAndWait(names);
    } 
    catch (TimeoutException | IOException e2) 
    {
      e2.printStackTrace();
      logger.severe(e2.getMessage());
    }

    List<TaskPromptSetContent> promptSets = new ArrayList<TaskPromptSetContent>();
    for (TaskPromptSetName name : names) 
    {
      TaskPromptSetContent content = new TaskPromptSetContent(name, exec.getRunID());
      try 
      {
        con.sendRequestAndWait(content);
      } 
      catch (TimeoutException | IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
      Iterator<PromptElement> iterator = content.iterator();
      while (iterator.hasNext()) 
      {
        PromptElement promptElement = iterator.next();
        String value = parameters.get(promptElement.getVariable());
        if (value == null)
            value = "";
        promptElement.setValue(value);
      }
      promptSets.add(content);
    }

    SubmitPrompt submit = new SubmitPrompt(names, promptSets.toArray(new TaskPromptSetContent[promptSets.size()]));
    try
    {
      con.sendRequestAndWait(submit);
    } 
    catch (TimeoutException | IOException e1)
    {
      e1.printStackTrace();
      logger.info(e1.getMessage());
    }
    try 
    {
        con.close();
    } 
    catch (IOException e) 
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
 
    return runId;
  }

  /*
   * (non-Javadoc)
   * @see com.capgemini.dac.automate.automationplugin.AutomationPlugin#getAutomationStatus(java.lang.String, java.lang.String, java.util.Map)
   */
  @Override
  public String getAutomationStatus(String environment, String customerIdentifier, Map<String, String> parameters)
  {
    String runId = parameters.get("runId");
    Connection con = null;
    
    Map<String, String> connectionConfiguration = null;
    try 
    {
      connectionConfiguration = getConnectionConfiguration();
    } 
    catch (IOException e1)
    {
      e1.printStackTrace();
      logger.severe(e1.getMessage());
    }
    String server = connectionConfiguration.get("SERVER_" + customerIdentifier + "_" + environment);
    String password = connectionConfiguration.get("PASSWORD_" + customerIdentifier + "_" + environment);
    String port = connectionConfiguration.get("PORT_" + customerIdentifier + "_" + environment);
    String client = connectionConfiguration.get("CLIENT_" + customerIdentifier + "_" + environment);
    String user = connectionConfiguration.get("USER_" + customerIdentifier + "_" + environment);
    String dept = connectionConfiguration.get("DEPT_" + customerIdentifier + "_" + environment);
    String language = connectionConfiguration.get("LANGUAGE_" + customerIdentifier + "_" + environment);

    // we are not going to open a connection at every single call.
    try
    {
      // opening the connection...
      // getting values of server and port from config file
      con = Connection.open(server, Integer.parseInt(port));
    }
    catch (NumberFormatException | IOException e) 
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    
    CreateSession logonRet = null;
    try 
    {
      logonRet = con.login(Integer.parseInt(client), user, dept, password, language.charAt(0));
    } 
    catch (NumberFormatException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    catch (IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    if (!logonRet.isLoginSuccessful())
      throw new IllegalArgumentException(logonRet.getMessageBox().getText());

    // filter expects the runID as a String
    // String runIDStr = Integer.toString(runID);
    GenericStatistics req = new GenericStatistics();
    req.selectAllPlatforms();
    req.selectAllTypes();
    req.setDateSelectionNone();
    req.setRunID(runId);
    try 
    {
      con.sendRequestAndWait(req);
    } 
    catch (TimeoutException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    catch (IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    Iterator<StatisticSearchItem> it = req.resultIterator();
    StatisticSearchItem item = null;
    while (it.hasNext()) 
    {
      item = it.next();
      System.out.println("\tItem:" + item.getName() + " RunID:" + item.getRunID() + " Type:" + item.getType()
                         + " " + item.getStatusText());
      logger.info("\tItem:" +item.getName() + " RunID:" + item.getRunID() + " Type:" + item.getType() + " " +item.getStatusText());
    }
    return item.getStatusText();
  }
  
  /**
   * This method is to take the configuration details of automic from a
   * configuration file. configuration parameters are:
   * server - which resembles the IP address or name of server, e.g.
   * Lab(DACLABAE01), cona-10.8.126.43
   * port - e.g. 2217
   * client - which resembles the client e.g. 100, 300 etc.
   * user - which resembles the userName e.g. ashaik11
   * password - which resembles the password
   * dept - which resembles the department e.g. ASMCOE
   * language-which resembles the language e.g. English
   */
  private Map<String, String> getConnectionConfiguration() throws IOException
  {
    Map<String, String> map = new HashMap<>();

    try 
    {
      Properties props = new Properties();
      String configFile = "/home/dac/automationapi/automationapi.properties";
      FileReader fReader = null;
      fReader = new FileReader(configFile);
      props.load(fReader);
      map.put("SERVER_con_dev", props.getProperty("SERVER_con_dev"));
      map.put("PORT_con_dev", props.getProperty("PORT_con_dev"));
      map.put("CLIENT_con_dev", props.getProperty("CLIENT_con_dev"));
      map.put("USER_con_dev", props.getProperty("USER_con_dev"));
      map.put("PASSWORD_con_dev", props.getProperty("PASSWORD_con_dev"));
      map.put("DEPT_con_dev", props.getProperty("DEPT_con_dev"));
      map.put("LANGUAGE_con_dev", props.getProperty("LANGUAGE_con_dev"));
      
      map.put("SERVER_con_qa", props.getProperty("SERVER_con_qa"));
      map.put("PORT_con_qa", props.getProperty("PORT_con_qa"));
      map.put("CLIENT_con_qa", props.getProperty("CLIENT_con_qa"));
      map.put("USER_con_qa", props.getProperty("USER_con_qa"));
      map.put("PASSWORD_con_qa", props.getProperty("PASSWORD_con_qa"));
      map.put("DEPT_con_qa", props.getProperty("DEPT_con_qa"));
      map.put("LANGUAGE_con_qa", props.getProperty("LANGUAGE_con_qa"));
      
      map.put("SERVER_con_pprd", props.getProperty("SERVER_con_pprd"));
      map.put("PORT_con_pprd", props.getProperty("PORT_con_pprd"));
      map.put("CLIENT_con_pprd", props.getProperty("CLIENT_con_pprd"));
      map.put("USER_con_pprd", props.getProperty("USER_con_pprd"));
      map.put("PASSWORD_con_pprd", props.getProperty("PASSWORD_con_pprd"));
      map.put("DEPT_con_pprd", props.getProperty("DEPT_con_pprd"));
      map.put("LANGUAGE_con_pprd", props.getProperty("LANGUAGE_con_pprd"));
      
      map.put("SERVER_con_pprd", props.getProperty("SERVER_con_pprd"));
      map.put("PORT_con_pprd", props.getProperty("PORT_con_pprd"));
      map.put("CLIENT_con_pprd", props.getProperty("CLIENT_con_pprd"));
      map.put("USER_con_pprd", props.getProperty("USER_con_pprd"));
      map.put("PASSWORD_con_pprd", props.getProperty("PASSWORD_con_pprd"));
      map.put("DEPT_con_pprd", props.getProperty("DEPT_con_pprd"));
      map.put("LANGUAGE_con_pprd", props.getProperty("LANGUAGE_con_pprd"));
      
      map.put("SERVER_con_prod", props.getProperty("SERVER_con_prod"));
      map.put("PORT_con_prod", props.getProperty("PORT_con_prod"));
      map.put("CLIENT_con_prod", props.getProperty("CLIENT_con_prod"));
      map.put("USER_con_prod", props.getProperty("USER_con_prod"));
      map.put("PASSWORD_con_prod", props.getProperty("PASSWORD_con_prod"));
      map.put("DEPT_con_prod", props.getProperty("DEPT_con_prod"));
      map.put("LANGUAGE_con_prod", props.getProperty("LANGUAGE_con_prod"));
      
      map.put("SERVER_wb_dev", props.getProperty("SERVER_wb_dev"));
      map.put("PORT_wb_dev", props.getProperty("PORT_wb_dev"));
      map.put("CLIENT_wb_dev", props.getProperty("CLIENT_wb_dev"));
      map.put("USER_wb_dev", props.getProperty("USER_wb_dev"));
      map.put("PASSWORD_wb_dev", props.getProperty("PASSWORD_wb_dev"));
      map.put("DEPT_wb_dev", props.getProperty("DEPT_wb_dev"));
      map.put("LANGUAGE_wb_dev", props.getProperty("LANGUAGE_wb_dev"));
      
      map.put("SERVER_wb_qa", props.getProperty("SERVER_wb_qa"));
      map.put("PORT_wb_qa", props.getProperty("PORT_wb_qa"));
      map.put("CLIENT_wb_qa", props.getProperty("CLIENT_wb_qa"));
      map.put("USER_wb_qa", props.getProperty("USER_wb_qa"));
      map.put("PASSWORD_wb_qa", props.getProperty("PASSWORD_wb_qa"));
      map.put("DEPT_wb_qa", props.getProperty("DEPT_wb_qa"));
      map.put("LANGUAGE_wb_qa", props.getProperty("LANGUAGE_wb_qa"));
      
      map.put("SERVER_wb_pprd", props.getProperty("SERVER_wb_pprd"));
      map.put("PORT_wb_pprd", props.getProperty("PORT_wb_pprd"));
      map.put("CLIENT_wb_pprd", props.getProperty("CLIENT_wb_pprd"));
      map.put("USER_wb_pprd", props.getProperty("USER_wb_pprd"));
      map.put("PASSWORD_wb_pprd", props.getProperty("PASSWORD_wb_pprd"));
      map.put("DEPT_wb_pprd", props.getProperty("DEPT_wb_pprd"));
      map.put("LANGUAGE_wb_pprd", props.getProperty("LANGUAGE_wb_pprd"));
      
      map.put("SERVER_wb_prod", props.getProperty("SERVER_wb_prod"));
      map.put("PORT_wb_prod", props.getProperty("PORT_wb_prod"));
      map.put("CLIENT_wb_prod", props.getProperty("CLIENT_wb_prod"));
      map.put("USER_wb_prod", props.getProperty("USER_wb_prod"));
      map.put("PASSWORD_wb_prod", props.getProperty("PASSWORD_wb_prod"));
      map.put("DEPT_wb_prod", props.getProperty("DEPT_wb_prod"));
      map.put("LANGUAGE_wb_prod", props.getProperty("LANGUAGE_wb_prod"));
      
      map.put("SERVER_tec_dev", props.getProperty("SERVER_tec_dev"));
      map.put("PORT_tec_dev", props.getProperty("PORT_tec_dev"));
      map.put("CLIENT_tec_dev", props.getProperty("CLIENT_tec_dev"));
      map.put("USER_tec_dev", props.getProperty("USER_tec_dev"));
      map.put("PASSWORD_tec_dev", props.getProperty("PASSWORD_tec_dev"));
      map.put("DEPT_tec_dev", props.getProperty("DEPT_tec_dev"));
      map.put("LANGUAGE_tec_dev", props.getProperty("LANGUAGE_tec_dev"));
      
      map.put("SERVER_tec_qa", props.getProperty("SERVER_tec_qa"));
      map.put("PORT_tec_qa", props.getProperty("PORT_tec_qa"));
      map.put("CLIENT_tec_qa", props.getProperty("CLIENT_tec_qa"));
      map.put("USER_tec_qa", props.getProperty("USER_tec_qa"));
      map.put("PASSWORD_tec_qa", props.getProperty("PASSWORD_tec_qa"));
      map.put("DEPT_tec_qa", props.getProperty("DEPT_tec_qa"));
      map.put("LANGUAGE_tec_qa", props.getProperty("LANGUAGE_tec_qa"));
      
      map.put("SERVER_tec_pprd", props.getProperty("SERVER_tec_pprd"));
      map.put("PORT_tec_pprd", props.getProperty("PORT_tec_pprd"));
      map.put("CLIENT_tec_pprd", props.getProperty("CLIENT_tec_pprd"));
      map.put("USER_tec_pprd", props.getProperty("USER_tec_pprd"));
      map.put("PASSWORD_tec_pprd", props.getProperty("PASSWORD_tec_pprd"));
      map.put("DEPT_tec_pprd", props.getProperty("DEPT_tec_pprd"));
      map.put("LANGUAGE_tec_pprd", props.getProperty("LANGUAGE_tec_pprd"));
      
      map.put("SERVER_tec_prod", props.getProperty("SERVER_tec_prod"));
      map.put("PORT_tec_prod", props.getProperty("PORT_tec_prod"));
      map.put("CLIENT_tec_prod", props.getProperty("CLIENT_tec_prod"));
      map.put("USER_tec_prod", props.getProperty("USER_tec_prod"));
      map.put("PASSWORD_tec_prod", props.getProperty("PASSWORD_tec_prod"));
      map.put("DEPT_tec_prod", props.getProperty("DEPT_tec_prod"));
      map.put("LANGUAGE_tec_prod", props.getProperty("LANGUAGE_tec_prod"));
      
      map.put("SERVER_ccn_dev", props.getProperty("SERVER_ccn_dev"));
      map.put("PORT_ccn_dev", props.getProperty("PORT_ccn_dev"));
      map.put("CLIENT_ccn_dev", props.getProperty("CLIENT_ccn_dev"));
      map.put("USER_ccn_dev", props.getProperty("USER_ccn_dev"));
      map.put("PASSWORD_ccn_dev", props.getProperty("PASSWORD_ccn_dev"));
      map.put("DEPT_ccn_dev", props.getProperty("DEPT_ccn_dev"));
      map.put("LANGUAGE_ccn_dev", props.getProperty("LANGUAGE_ccn_dev"));
      
      map.put("SERVER_ccn_qa", props.getProperty("SERVER_ccn_qa"));
      map.put("PORT_ccn_qa", props.getProperty("PORT_ccn_qa"));
      map.put("CLIENT_ccn_qa", props.getProperty("CLIENT_ccn_qa"));
      map.put("USER_ccn_qa", props.getProperty("USER_ccn_qa"));
      map.put("PASSWORD_ccn_qa", props.getProperty("PASSWORD_ccn_qa"));
      map.put("DEPT_ccn_qa", props.getProperty("DEPT_ccn_qa"));
      map.put("LANGUAGE_ccn_qa", props.getProperty("LANGUAGE_ccn_qa"));
      
      map.put("SERVER_ccn_pprd", props.getProperty("SERVER_ccn_pprd"));
      map.put("PORT_ccn_pprd", props.getProperty("PORT_ccn_pprd"));
      map.put("CLIENT_ccn_pprd", props.getProperty("CLIENT_ccn_pprd"));
      map.put("USER_ccn_pprd", props.getProperty("USER_ccn_pprd"));
      map.put("PASSWORD_ccn_pprd", props.getProperty("PASSWORD_ccn_pprd"));
      map.put("DEPT_ccn_pprd", props.getProperty("DEPT_ccn_pprd"));
      map.put("LANGUAGE_ccn_pprd", props.getProperty("LANGUAGE_ccn_pprd"));
      
      map.put("SERVER_ccn_prod", props.getProperty("SERVER_ccn_prod"));
      map.put("PORT_ccn_prod", props.getProperty("PORT_ccn_prod"));
      map.put("CLIENT_ccn_prod", props.getProperty("CLIENT_ccn_prod"));
      map.put("USER_ccn_prod", props.getProperty("USER_ccn_prod"));
      map.put("PASSWORD_ccn_prod", props.getProperty("PASSWORD_ccn_prod"));
      map.put("DEPT_ccn_prod", props.getProperty("DEPT_ccn_prod"));
      map.put("LANGUAGE_ccn_prod", props.getProperty("LANGUAGE_ccn_prod"));
      
      map.put("SERVER_mej_dev", props.getProperty("SERVER_mej_dev"));
      map.put("PORT_mej_dev", props.getProperty("PORT_mej_dev"));
      map.put("CLIENT_mej_dev", props.getProperty("CLIENT_mej_dev"));
      map.put("USER_mej_dev", props.getProperty("USER_mej_dev"));
      map.put("PASSWORD_mej_dev", props.getProperty("PASSWORD_mej_dev"));
      map.put("DEPT_mej_dev", props.getProperty("DEPT_mej_dev"));
      map.put("LANGUAGE_mej_dev", props.getProperty("LANGUAGE_mej_dev"));
      
      map.put("SERVER_mej_qa", props.getProperty("SERVER_mej_qa"));
      map.put("PORT_mej_qa", props.getProperty("PORT_mej_qa"));
      map.put("CLIENT_mej_qa", props.getProperty("CLIENT_mej_qa"));
      map.put("USER_mej_qa", props.getProperty("USER_mej_qa"));
      map.put("PASSWORD_mej_qa", props.getProperty("PASSWORD_mej_qa"));
      map.put("DEPT_mej_qa", props.getProperty("DEPT_mej_qa"));
      map.put("LANGUAGE_mej_qa", props.getProperty("LANGUAGE_mej_qa"));
      
      map.put("SERVER_mej_pprd", props.getProperty("SERVER_mej_pprd"));
      map.put("PORT_mej_pprd", props.getProperty("PORT_mej_pprd"));
      map.put("CLIENT_mej_pprd", props.getProperty("CLIENT_mej_pprd"));
      map.put("USER_mej_pprd", props.getProperty("USER_mej_pprd"));
      map.put("PASSWORD_mej_pprd", props.getProperty("PASSWORD_mej_pprd"));
      map.put("DEPT_mej_pprd", props.getProperty("DEPT_mej_pprd"));
      map.put("LANGUAGE_mej_pprd", props.getProperty("LANGUAGE_mej_pprd"));
      
      map.put("SERVER_mej_prod", props.getProperty("SERVER_mej_prod"));
      map.put("PORT_mej_prod", props.getProperty("PORT_mej_prod"));
      map.put("CLIENT_mej_prod", props.getProperty("CLIENT_mej_prod"));
      map.put("USER_mej_prod", props.getProperty("USER_mej_prod"));
      map.put("PASSWORD_mej_prod", props.getProperty("PASSWORD_mej_prod"));
      map.put("DEPT_mej_prod", props.getProperty("DEPT_mej_prod"));
      map.put("LANGUAGE_mej_prod", props.getProperty("LANGUAGE_mej_prod"));
      
      map.put("SERVER_lab_lab", props.getProperty("SERVER_lab_lab"));
      map.put("PORT_lab_lab", props.getProperty("PORT_lab_lab"));
      map.put("CLIENT_lab_lab", props.getProperty("CLIENT_lab_lab"));
      map.put("USER_lab_lab", props.getProperty("USER_lab_lab"));
      map.put("PASSWORD_lab_lab", props.getProperty("PASSWORD_lab_lab"));
      map.put("DEPT_lab_lab", props.getProperty("DEPT_lab_lab"));
      map.put("LANGUAGE_lab_lab", props.getProperty("LANGUAGE_lab_lab"));
    } 
    catch (FileNotFoundException e) 
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    return map;
  }

  /**
   * Dummy main method for the jar export.
   */
  public static void main(String[] args) throws Exception
  {
  }
}
