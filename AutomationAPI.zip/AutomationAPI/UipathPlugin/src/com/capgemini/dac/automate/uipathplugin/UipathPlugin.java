/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.uipathplugin;

import com.capgemini.dac.automate.automationplugin.AutomationPlugin;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * This class implements the UiPath Automation Plugin. It implements
 * AutomationPlugin which is the plugin contract.
 * 
 * @author Shaik Abdul Sharukh
 */
public class UipathPlugin implements AutomationPlugin
{
  CertificateManager certManager;
  ConfigurationClass config;
  private static final int HTTP_STATUS_OK = 201;
  private static final Logger logger = Logger.getLogger(UipathPlugin.class.getName());

  /**
   * Default constructor.
   */
  public UipathPlugin()
  {
    certManager = new CertificateManager();
    config = new ConfigurationClass();
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.capgemini.dac.automate.automationplugin.AutomationPlugin#startAutomation(
   * java.lang.String, java.lang.String, java.util.Map)
   */
  @Override
  public String startAutomation(String environment, String customerIdentifier, Map<String, String> parameters)
  {

    Map<String, String> connnectionConfiguration = null;

    try
    {
      connnectionConfiguration = config.getcon();
    }
    catch (IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    String automationName = parameters.get("automationName");
    String userName = connnectionConfiguration.get("UIPATH_USERNAME_" + customerIdentifier + "_" + environment);
    String password = connnectionConfiguration.get("UIPATH_PASSWORD_" + customerIdentifier + "_" + environment);
    String url = connnectionConfiguration.get(environment + "_url");
    System.out.println("username,url::" + userName + url);
    logger.info("username,url::" + userName + url);

    // ignore SSL certs
    certManager.ignoreSSLCertificates();

    // log-in to UiPath Orchestrator with username and password
    JSONObject jsonObj = new JSONObject();
    try
    {
      jsonObj.put("usernameOrEmailAddress", userName);
      jsonObj.put("password", password);
    }
    catch (JSONException e)
    {
      e.printStackTrace();
      logger.info(e.getMessage());
    }

    // calling the method of authentication and getting the bearer token
    String bearer = null;
    try
    {
      bearer = authenticate(jsonObj, url + "/api/Account/Authenticate");
    }
    catch (Exception e1)
    {
      e1.printStackTrace();
      logger.severe(e1.getMessage());
    }

    String authKey = "Bearer " + bearer.replace("\"", "");
    parameters.remove("automationName");
    JSONObject inputArguments = new JSONObject(parameters);

    // calling the getRelease method to get the release key by invoking
    // Releases API
    List<String> releaseKey = null;
    try
    {
      releaseKey = getRelease(url + "/odata/Releases", authKey, automationName);
    }
    catch (IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());

    }

    System.out.println(" release" + releaseKey);
    logger.info("releaseKey is:" + releaseKey);

    List<String> initialBotId = null;
    try
    {
      // get the robot ID
      initialBotId = getBotId(authKey, automationName, url, releaseKey);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    System.out.println("Initial robot ID returned when environment API is hit: " + initialBotId);
    logger.info("Initial robot ID returned when environment API is hit: " + initialBotId);

    int responseCode = 0;
    String runId = null;
    String finalBotId = null;
    for (int p = 0; p < initialBotId.size(); p++)
    {

      URL urlforSessions = null;
      try
      {
        //This is the url for checking the sessions of the botId's which we got as a list from getBotId
        //method. In this url botId's are passed as a list and looped.
        //When the below filtering is added, the states of the robot's are given back as a response.
        
        urlforSessions = new URL(
            url + "/odata/Sessions?$filter=Robot%2FId%20eq%20" + initialBotId.get(p) + "&$select=State");
      }
      catch (MalformedURLException e2)
      {
        e2.printStackTrace();
        logger.severe(e2.getMessage());
      }
      HttpsURLConnection connection = null;
      try
      {
        connection = (HttpsURLConnection) urlforSessions.openConnection();
      }
      catch (IOException e3)
      {
        e3.printStackTrace();
        logger.severe(e3.getMessage());       
      }
      try
      {
        connection.setRequestMethod("GET");
      }
      catch (ProtocolException e2)
      {
        e2.printStackTrace();
        logger.severe(e2.getMessage());
      }
      connection.setRequestProperty("Authorization", authKey);
      connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
      connection.setRequestProperty("User-Agent",
          "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
      int responseCodeforSession = 0;
      try
      {
        responseCodeforSession = connection.getResponseCode();
      }
      catch (IOException e2)
      {
        e2.printStackTrace();
        logger.severe(e2.getMessage());
      }
      StringBuffer response = new StringBuffer();
      System.out.println("GET Response Code for robotssession :: " + responseCodeforSession);
      logger.info("GET Response Code for robotssession :: " + responseCodeforSession);

      if (responseCodeforSession == HttpsURLConnection.HTTP_OK)// success
      {
        BufferedReader bufferReader = null;
        try
        {
          bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        }
        catch (IOException e1)
        {
          e1.printStackTrace();
          logger.severe(e1.getMessage());
        }
        String inputLine;

        try
        {
          while ((inputLine = bufferReader.readLine()) != null)
          {
            response.append(inputLine);
          }
        }
        catch (IOException e2)
        {
          e2.printStackTrace();
          logger.severe(e2.getMessage());
        }
        try
        {
          bufferReader.close();
        }
        catch (IOException e1)
        {
          e1.printStackTrace();
          logger.severe(e1.getMessage());
        }

        JSONArray jsonArray;
        try
        {
          jsonObj = new JSONObject(response.toString());
          jsonArray = (JSONArray) jsonObj.get("value");

          JSONObject stateValue = (JSONObject) jsonArray.get(0);
          //Checking the value present inside State.
          String statedFinally = stateValue.getString("State");
          System.out.println("Checking for the session"+statedFinally);
          logger.info("Checking for the session::"+statedFinally);
          //Only if the value is "Available", it is made as a finalBotId(which is required to run an Automation)
          //and automation is run.
          if (statedFinally.equals("Available"))
          {
            List<String> addedString = new ArrayList<String>();
            addedString.add(statedFinally);
            finalBotId = initialBotId.get(p);
            System.out.println("Final BotID::" + finalBotId);
            logger.info("Final BotID::" + finalBotId);
            break;
          }
        }
        catch (JSONException e)
        {
          e.printStackTrace();
          logger.severe(e.getMessage());
        }
        System.out.println("response of session" + response.toString());
        logger.info("response of session" + response.toString());
      }
      else
      {
        System.out.println("GET request not worked");
        logger.info("GET request not worked");
      }
    }

    // checking for the botId which we have is 
    // null or not."initialbotId" and "finalbotId" are the two variables which
    // were named.initialbotId is the botId which we got while hitting the
    // environmentAPI
    // we will check for the sessions(states) of all the robots
    // finalbotId is the botId which we will get after checking
    // states of all robots.
    // finalbotId is the botId which we will pass into the start job API

    logger.info("Final BotID::" + finalBotId);
    if (!finalBotId.equals(null))
    {
      JSONObject jsonObject = new JSONObject();
      JSONObject request = new JSONObject();
      JSONArray jarray = new JSONArray();
      try
      {
        // passing required parameters to invoke the startjob API
        jarray.put((Integer.parseInt(finalBotId)));
        // releaseKey.get(0) is having the release key
        request.put("ReleaseKey", releaseKey.get(0));
        request.put("Strategy", "Specific");
        request.put("NoOfRobots", 0);
        request.put("RobotIds", jarray);
        request.put("Source", "Manual");
        // inputArguments have been passed into the post request of startJOB API itself.
        request.put("InputArguments", inputArguments.toString());
        jsonObject.put("startInfo", request);
      }
      catch (JSONException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }

      System.out.println("ReleaseKey::" + releaseKey.get(0));
      logger.info("ReleaseKey::" + releaseKey.get(0));
      URL urlforStartAutomation = null;
      try
      {
        // hitting the Start Job API
        urlforStartAutomation = new URL(url + "/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs");
      }
      catch (MalformedURLException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }

      HttpsURLConnection connectionforStartAutomation = null;
      try
      {
        connectionforStartAutomation = (HttpsURLConnection) urlforStartAutomation.openConnection();
      }
      catch (IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }

      try
      {
        connectionforStartAutomation.setRequestMethod("POST");
      }
      catch (ProtocolException e1)
      {
        e1.printStackTrace();
        logger.severe(e1.getMessage());
      }

      connectionforStartAutomation.setRequestProperty("Authorization", authKey);
      connectionforStartAutomation.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
      connectionforStartAutomation.setRequestProperty("User-Agent",
          "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
      connectionforStartAutomation.setDoOutput(true);
      DataOutputStream outStream;
      try
      {
        outStream = new DataOutputStream(connectionforStartAutomation.getOutputStream());
        outStream.write(jsonObject.toString().getBytes(StandardCharsets.UTF_8));
        outStream.flush();
        outStream.close();
        responseCode = connectionforStartAutomation.getResponseCode();
      }
      catch (IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }

      System.out.println("POST Response Code for STARTJOB :: " + responseCode);
      logger.info("POST Response Code for STARTJOB :: " + responseCode);
      if (responseCode == HTTP_STATUS_OK) // success
      {
        BufferedReader bufferReader = null;
        try
        {
          bufferReader = new BufferedReader(new InputStreamReader(connectionforStartAutomation.getInputStream()));
        }
        catch (IOException e1)
        {
          e1.printStackTrace();
          logger.severe(e1.getMessage());
        }
        String inputLine;
        StringBuffer response1 = new StringBuffer();

        try
        {
          while ((inputLine = bufferReader.readLine()) != null)
          {
            response1.append(inputLine);
          }
        }
        catch (IOException e)
        {
          e.printStackTrace();
          logger.severe(e.getMessage());
        }

        JSONObject jsonobjAutomationresponse;
        try
        {
          jsonobjAutomationresponse = new JSONObject(response1.toString());
          System.out.println("Response of START AUTOMATION" + jsonobjAutomationresponse);
          logger.info("Response of START AUTOMATION" + jsonobjAutomationresponse);
          JSONArray jArr = new JSONArray();
          jArr = (JSONArray) jsonobjAutomationresponse.get("value");
          for (int k = 0; k < jArr.length(); k++)
          {
            JSONObject jsonProcess = jArr.getJSONObject(k);
            runId = jsonProcess.get("Id").toString();
            System.out.println("Run ID:" + runId);
            logger.info("Run ID:" + runId);

          }
        }
        catch (JSONException e)
        {
          e.printStackTrace();
          logger.severe(e.getMessage());
        }
      }
      else
      {
        System.out.println("POST request not worked");
        logger.info("POST request not worked");
      }

    }

    else
    {
      runId = "runId is null.Please check whether the bot session is available or not";
    }

    // returning the Id which is there in the response after hitting Start Job API
    return runId;
  }

  /**
   * This method is to Authenticate the user who logs into UipathOrchestrator
   * 
   * @param jsonObj contains usernameOrEmailAddress and password
   * @param url defines environment URL (Eg: DEV url, QA url, PROD url)
   * @return getBearer(response)-returns response which is a bearer token which
   * inturn is used for authentication
   * @throws Exception
   */
  public String authenticate(JSONObject jsonObj, String url) throws Exception
  {
    // ignore SSL certs
    System.out.println("Authentication url is " + url);
    logger.info("Authentication url is " + url);
    certManager.ignoreSSLCertificates();
    StringBuffer response = new StringBuffer();
    URL urlforAuthentication = new URL(url);
    HttpsURLConnection connection = (HttpsURLConnection) urlforAuthentication.openConnection();

    // TODO This chuck of code seems to be repeated multiple times in the code
    // As I am using API's I have to specify the content types and
    // type of request(POST or GET). The same thing I have written when I have used
    // API's in
    // different methods.
    connection.setRequestMethod("POST");
    connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
    connection.setRequestProperty("User-Agent",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
    connection.setDoOutput(true);
    DataOutputStream outStream = new DataOutputStream(connection.getOutputStream());
    outStream.write(jsonObj.toString().getBytes(StandardCharsets.UTF_8));
    outStream.flush();
    outStream.close();
    int responseCode = connection.getResponseCode();
    System.out.println("POST Response Code for AUTHENTICATION :: " + responseCode);
    logger.info("POST Response Code for AUTHENTICATION :: " + responseCode);

    if (responseCode == HttpsURLConnection.HTTP_OK)// success
    {
      BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
      String inputLine;
      while ((inputLine = bufferReader.readLine()) != null)
      {
        response.append(inputLine);
      }

      bufferReader.close();
    }
    else
    {
      System.out.println("POST request not worked");
      logger.info("POST request not worked");
    }

    return getBearer(response);
  }

  /**
   * @param url defines environment URL (Eg: DEV url, QA url, PROD url)
   * @param AuthKey contains the bearer token which is used for authentication
   * @param automationName is the automation that has to run
   * @return list object which contains releasekey and environmentId
   * @throws IOException
   **/
  public List<String> getRelease(String url, String AuthKey, String automationName) throws IOException
  {
    // ignore SSL certs
    certManager.ignoreSSLCertificates();
    URL urlforRelease = new URL(url);
    HttpsURLConnection connection = (HttpsURLConnection) urlforRelease.openConnection();
    connection.setRequestMethod("GET");
    connection.setRequestProperty("Authorization", AuthKey);
    connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
    connection.setRequestProperty("User-Agent",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
    int responseCode = connection.getResponseCode();
    StringBuffer response = new StringBuffer();
    System.out.println("GET Response Code :: " + responseCode);
    logger.info("GET Response Code :: " + responseCode);

    List<String> list = new ArrayList<String>();
    if (responseCode == HttpsURLConnection.HTTP_OK)// success
    {
      BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
      String inputLine;
      while ((inputLine = bufferReader.readLine()) != null)
      {
        response.append(inputLine);
      }
      bufferReader.close();
      JSONObject jsonObj;
      try
      {
        jsonObj = new JSONObject(response.toString());
        JSONArray jArr = new JSONArray();
        jArr = (JSONArray) jsonObj.get("value");
        for (int i = 0; i < jArr.length(); i++)
        {
          JSONObject jsonProcess = jArr.getJSONObject(i);
          // getting the value of processkey
          String processKey = jsonProcess.getString("ProcessKey");
          // checking whether that value of process equals
          // to our process. Our processname is which comes from json
          // while hitting the webservice.It is stored in variable
          // AutomationName.If these both are equal,pull out the
          // values of Key and environmentId.
          // Key is nothing but the release key

          if (processKey.equals(automationName))
          {
            list.add(jsonProcess.getString("Key"));
            list.add(jsonProcess.get("EnvironmentId").toString());
            System.out.println("listing list" + list);
            logger.info("listing list" + list);
            break;
          }
        }
      }
      catch (JSONException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
      System.out.println("response for release" + response.toString());
      logger.info("response for release" + response.toString());
    }
    else
    {
      System.out.println("GET request not worked");
      logger.info("GET request not worked");
    }

    return list;
  }

  /**
   * Gets the bearer token as part of Uipath Orchestrator authentication process.
   * 
   * @param response string token
   * @return the bearer
   */
  private String getBearer(StringBuffer response)
  {
    String result = response.toString();
    String[] split = result.split(",");
    String split1 = split[0];
    String[] split2 = split1.split(":");
    String bearer = split2[1];
    return bearer;
  }

  /**
   * This method returns a list of all the ids of the robots associated to an
   * environment based on environment Id
   * 
   * @param AuthKey contains the bearer token which is used for authentication
   * @param automationName is the automation that has to run
   * @param url defines environment URL (Eg: DEV url, QA url, PROD url)
   * @param releaseKey which is a release for the process(automation that has to
   * run)
   * @return robotList which we get when environment API is invoked
   * @throws Exception
   */
  public List<String> getBotId(String AuthKey, String automationName, String url, List<String> releaseKey)
      throws Exception
  {

    certManager.ignoreSSLCertificates();
    // hitting the Environment URL by passing the EnvironmentId into it.
    // The EnvironmentId and releaseKey both we got when we hit the url of
    // releases.
    // I have stored both the values in the variable releaseKey.
    // releaseKey.get(0) is holding the releaseKey
    // releaseKey.get(1) is holding the value of EnvironmentId.
    URL urlforEnvironment = new URL(

        url + "/odata/Environments/UiPath.Server.Configuration.OData.GetRobotIdsForEnvironment(key=" + releaseKey.get(1)
            + ")");
    HttpsURLConnection connection = (HttpsURLConnection) urlforEnvironment.openConnection();
    connection.setRequestMethod("GET");
    connection.setRequestProperty("Authorization", AuthKey);
    connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
    connection.setRequestProperty("User-Agent",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
    int responseCode = connection.getResponseCode();
    StringBuffer response = new StringBuffer();
    System.out.println("GET Response Code for Environment :: " + responseCode);
    logger.info("GET Response Code for Environment :: " + responseCode);

    List<String> robotList = new ArrayList<>();
    JSONArray jArr = new JSONArray();
    if (responseCode == HttpsURLConnection.HTTP_OK)// success
    {
      BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
      String inputLine;
      while ((inputLine = bufferReader.readLine()) != null)
      {
        response.append(inputLine);
      }
      bufferReader.close();
      JSONObject jsonObj;
      try
      {
        jsonObj = new JSONObject(response.toString());
        jArr = (JSONArray) jsonObj.get("value");
        for (int i = 0; i < jArr.length(); i++)
        {
          robotList.add(jArr.get(i).toString());
        }
      }
      catch (JSONException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
      System.out.println("response for environment" + response.toString());
      logger.info("response for environment" + response.toString());
    }
    else
    {
      System.out.println("GET request not worked");
      logger.info("GET request not worked");
    }

    return robotList;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.capgemini.dac.automate.automationplugin.AutomationPlugin#
   * getAutomationEngineName()
   */
  @Override
  public String getAutomationEngineName()
  {
    return "uipath";
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.capgemini.dac.automate.automationplugin.AutomationPlugin#
   * getAutomationStatus(java.lang.String, java.lang.String, java.util.Map)
   */
  @Override
  public String getAutomationStatus(String environment, String customerIdentifier, Map<String, String> parameters)
  {
    Map<String, String> connectionConfiguration = null;

    try
    {
      connectionConfiguration = config.getcon();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }

    String status = null;
    String userName = connectionConfiguration.get("UIPATH_USERNAME_" + customerIdentifier + "_" + environment);
    String password = connectionConfiguration.get("UIPATH_PASSWORD_" + customerIdentifier + "_" + environment);
    String url = connectionConfiguration.get(environment + "_url");
    System.out.println("username,url::" + userName + url);
    logger.info("username,url::" + userName + url);

    // ignore SSL certs
    certManager.ignoreSSLCertificates();

    // log-in to UiPath Orchestrator with username and password
    JSONObject jsonObj = new JSONObject();
    try
    {
      jsonObj.put("usernameOrEmailAddress", userName);
      jsonObj.put("password", password);
    }
    catch (JSONException e1)
    {
      e1.printStackTrace();
      logger.severe(e1.getMessage());
    }

    // calling the method of authentication and getting the bearer token
    String bearer = null;
    try
    {
      bearer = authenticate(jsonObj, url + "/api/Account/Authenticate");
    }
    catch (Exception e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    String authKey = "Bearer " + bearer.replace("\"", "");
    certManager.ignoreSSLCertificates();
    String runId = parameters.get("runId");
    URL urlforStatus = null;
    try
    {
      urlforStatus = new URL(url + "/odata/Jobs(" + runId + ")");
      System.out.println("printing the status url::" + urlforStatus);
      logger.info("printing the status url::" + urlforStatus);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    HttpsURLConnection connection = null;
    int responseCode = 0;
    try
    {
      connection = (HttpsURLConnection) urlforStatus.openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Authorization", authKey);
      connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
      connection.setRequestProperty("User-Agent",
          "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
      responseCode = connection.getResponseCode();
    }
    catch (IOException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }

    StringBuffer response = new StringBuffer();
    System.out.println("GET Response for jobs status:: " + responseCode);
    logger.info("GET Response for jobs status:: " + responseCode);
    if (responseCode == HttpsURLConnection.HTTP_OK)// success
    {
      BufferedReader bufferReader;
      String inputLine = null;
      try
      {
        bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        while ((inputLine = bufferReader.readLine()) != null)
        {
          response.append(inputLine);
        }
      }
      catch (IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }

      JSONObject jsonObject;
      System.out.println("reponse job status::" + response);
      logger.info("reponse job status::" + response);
      try
      {
        jsonObject = new JSONObject(response.toString());
        System.out.println("response" + jsonObject);
        logger.info("response" + jsonObject);
        status = jsonObject.getString("State");
        System.out.println("State:" + status);
        logger.info("State:" + status);
      }
      catch (JSONException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
    }

    return status;
  }

  /**
   * Dummy main method for the jar export.
   */
  public static void main(String[] args) throws Exception
  {
  }
}