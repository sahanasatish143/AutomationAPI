/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.uipathplugin;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * This class represents the configuration parameters for the Uipath Plugin
 * 
 * @author Shaik Abdul Sharukh
 */
public class ConfigurationClass
{
  /**
   * This method is to fetch the configuration file from the 
   * file location and read the parameters from it.
   * 
   * List of parameters:
   * username - username for the UiPath Orchestrator login. This username
   * is specific to environment and client
   * 
   * password - password for the UiPath Orchestrator login. This password
   * is specific to environment and client
   * 
   * url - It specifies the url..eg..QA-url, Dev-url,Prod-url.
   * 
   * @return map of configuration parameters
   * @throws IOException
   */ 
 
  public  Map<String,String> getcon() throws IOException
  {
    Map<String,String>map = new HashMap<>();
    try
    {
      Properties props = new Properties();    
      String configFile = "/home/dac/automationapi/automationapi.properties";
      FileReader fReader = null;
      fReader = new FileReader(configFile);      
      props.load(fReader);            
      map.put("qa_url", props.getProperty("qa_url"));
      map.put("dev_url", props.getProperty("dev_url"));
      map.put("prod_url",props.getProperty("prod_url"));
      map.put("lab_url",props.getProperty("lab_url")); 
      
      map.put("UIPATH_USERNAME_lab_lab", props.getProperty("UIPATH_USERNAME_lab_lab"));
      map.put("UIPATH_PASSWORD_lab_lab", props.getProperty("UIPATH_PASSWORD_lab_lab"));
      
      map.put("UIPATH_USERNAME_tec_dev", props.getProperty("UIPATH_USERNAME_tec_dev"));
      map.put("UIPATH_PASSWORD_tec_dev", props.getProperty("UIPATH_PASSWORD_tec_dev"));
      map.put("UIPATH_USERNAME_tec_qa", props.getProperty("UIPATH_USERNAME_tec_qa"));
      map.put("UIPATH_PASSWORD_tec_qa", props.getProperty("UIPATH_PASSWORD_tec_qa"));
      map.put("UIPATH_USERNAME_tec_pprd", props.getProperty("UIPATH_USERNAME_tec_pprd"));
      map.put("UIPATH_PASSWORD_tec_pprd", props.getProperty("UIPATH_PASSWORD_tec_pprd"));
      map.put("UIPATH_USERNAME_tec_prod", props.getProperty("UIPATH_USERNAME_tec_prod"));
      map.put("UIPATH_PASSWORD_tec_prod", props.getProperty("UIPATH_PASSWORD_tec_prod"));
      
      map.put("UIPATH_USERNAME_con_dev", props.getProperty("UIPATH_USERNAME_con_dev"));
      map.put("UIPATH_PASSWORD_con_dev", props.getProperty("UIPATH_PASSWORD_con_dev"));
      map.put("UIPATH_USERNAME_con_qa", props.getProperty("UIPATH_USERNAME_con_qa"));
      map.put("UIPATH_PASSWORD_con_qa", props.getProperty("UIPATH_PASSWORD_con_qa"));
      map.put("UIPATH_USERNAME_con_pprd", props.getProperty("UIPATH_USERNAME_con_pprd"));
      map.put("UIPATH_PASSWORD_con_pprd", props.getProperty("UIPATH_PASSWORD_con_pprd"));
      map.put("UIPATH_USERNAME_con_prod", props.getProperty("UIPATH_USERNAME_con_prod"));
      map.put("UIPATH_PASSWORD_con_prod", props.getProperty("UIPATH_PASSWORD_con_prod"));
      
      map.put("UIPATH_USERNAME_mej_dev", props.getProperty("UIPATH_USERNAME_mej_dev"));
      map.put("UIPATH_PASSWORD_mej_dev", props.getProperty("UIPATH_PASSWORD_mej_dev"));
      map.put("UIPATH_USERNAME_mej_qa", props.getProperty("UIPATH_USERNAME_mej_qa"));
      map.put("UIPATH_PASSWORD_mej_qa", props.getProperty("UIPATH_PASSWORD_mej_qa"));
      map.put("UIPATH_USERNAME_mej_pprd", props.getProperty("UIPATH_USERNAME_mej_pprd"));
      map.put("UIPATH_PASSWORD_mej_pprd", props.getProperty("UIPATH_PASSWORD_mej_pprd"));
      map.put("UIPATH_USERNAME_mej_prod", props.getProperty("UIPATH_USERNAME_mej_prod"));
      map.put("UIPATH_PASSWORD_mej_prod", props.getProperty("UIPATH_PASSWORD_mej_prod"));
      
      map.put("UIPATH_USERNAME_ccna_dev", props.getProperty("UIPATH_USERNAME_ccna_dev"));
      map.put("UIPATH_PASSWORD_ccna_dev", props.getProperty("UIPATH_PASSWORD_ccna_dev"));
      map.put("UIPATH_USERNAME_ccna_qa", props.getProperty("UIPATH_USERNAME_ccna_qa"));
      map.put("UIPATH_PASSWORD_ccna_qa", props.getProperty("UIPATH_PASSWORD_ccna_qa"));
      map.put("UIPATH_USERNAME_ccna_pprd", props.getProperty("UIPATH_USERNAME_ccna_pprd"));
      map.put("UIPATH_PASSWORD_ccna_pprd", props.getProperty("UIPATH_PASSWORD_ccna_pprd"));
      map.put("UIPATH_USERNAME_ccna_prod", props.getProperty("UIPATH_USERNAME_ccna_prod"));
      map.put("UIPATH_PASSWORD_ccna_prod", props.getProperty("UIPATH_PASSWORD_ccna_prod"));
      
      map.put("UIPATH_USERNAME_wb_dev", props.getProperty("UIPATH_USERNAME_wb_dev"));
      map.put("UIPATH_PASSWORD_wb_dev", props.getProperty("UIPATH_PASSWORD_wb_dev"));
      map.put("UIPATH_USERNAME_wb_qa", props.getProperty("UIPATH_USERNAME_wb_qa"));
      map.put("UIPATH_PASSWORD_wb_qa", props.getProperty("UIPATH_PASSWORD_wb_qa"));
      map.put("UIPATH_USERNAME_wb_pprd", props.getProperty("UIPATH_USERNAME_wb_pprd"));
      map.put("UIPATH_PASSWORD_wb_pprd", props.getProperty("UIPATH_PASSWORD_wb_pprd"));
      map.put("UIPATH_USERNAME_wb_prod", props.getProperty("UIPATH_USERNAME_wb_prod"));
      map.put("UIPATH_PASSWORD_wb_prod", props.getProperty("UIPATH_PASSWORD_wb_prod"));     
    }
    catch (FileNotFoundException e) 
    {
      e.printStackTrace();
    }

    return map;
  }
}
