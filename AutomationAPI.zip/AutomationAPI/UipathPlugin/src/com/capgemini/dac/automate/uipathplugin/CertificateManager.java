/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.uipathplugin;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 *This class disables SSL certificate checking for instances of UiPath 
 *HttpsUrlConnection  
 * @author Shaik Abdul Sharukh
 */
public class CertificateManager
{
  String bearer1 = null;
 
  /**
   *Method implemented to bypass SSL Handshake Exception
   *instances of UiPath HttpsUrlConnection unless trusted certificate is installed 
   *in the required server
   */
  void ignoreSSLCertificates()
  {
    // holds context of all SSL Certificates of which X509TrustManager which
    // is signed by unknown authority
    TrustManager[] trustAllCerts = new TrustManager[]
    {
      new X509TrustManager()
      {
        public java.security.cert.X509Certificate[] getAcceptedIssuers()
        {
          return null;
        }
  
        /**
         * This method is to check the certificate for the client
         */
        @Override
        public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException
        {        
        }
  
        /**
         * This method is to check the certificate for server
         */
        @Override
        public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException
        {
        }
      } 
    };

    SSLContext sc = null;
    try
    {
      sc = SSLContext.getInstance("SSL");
    }
    catch (NoSuchAlgorithmException e)
    {
      System.out.println("No such algorithm exception" + e.getMessage());
    }

    try
    {
      sc.init(null, trustAllCerts, new java.security.SecureRandom());
    }
    catch (KeyManagementException e)
    {
      System.out.println("key management exception" + e.getMessage());
    }

    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

    // create all-trusting host name verifier
    HostnameVerifier allHostsValid = new HostnameVerifier()
    {
      public boolean verify(String hostname, SSLSession session)
      {
        return true;
      }
    };

    // install the all-trusting host verifier
    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    
  }// ignoreSSLCertificates
}
