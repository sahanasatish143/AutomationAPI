/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate.automationapi.AutomationAPI;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;


import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
* This class represents the main resource for the web service. In where we
* accept web request and we invoke the different plugins, e.g. Automic Plugin,
* UiPath Plugin etc.
* 
 * @author Shaik Abdul Sharukh
*/
@Path("/automation")
public class MainResource
{
  private static final String CONFIGURATION_FILE_PATH = "/home/dac/automationapi/automationapi.properties";
  private static final Logger logger = Logger.getLogger(MainResource.class.getName());
  private PluginManager pluginManager;
  
 
  /**
   * Default constructor. Instantiates attributes.
   * 
   */
  public MainResource()
  {
    
    try
    {
      InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("logging.properties");
      LogManager.getLogManager().readConfiguration(inputStream);
      logger.info("Initializing logger");
    }
    catch (Exception e)
    {
      System.out.println("ERROR: While initializing logger");
      e.printStackTrace();
    }  
    Map<String, String> configuration = null;
    try
    {
      configuration = readProperties();
    }
    catch (IOException e2)
    {
      e2.printStackTrace();
    }
    String path = configuration.get("PATH_TO_PLUGIN_DIRECTORY");   
    // load all plugins in plugin directory
    pluginManager = PluginManager.getInstance(path);
    System.out.println("plugin loaded");
  }

  /**
   * This function is to get the payload from the request.The request data is of the form json
   * and all those are mapped into hashmap object of key value pairs and depending on the 
   * parameter action(start or status), will call the respective methods in 
   * UipathPlugin and AutomicPlugin.  
   * 
   * @param payLoad specifies the json data ..eg.automationName,action,automationEngine,
   * environment,customerIdentifier.
   * action- specifies the whether to start Automation or get the status of
   * Automation...{start or status}
   * automationEngine- specifies the type of automationEngine
   * (Automic,Uipath...etc)
   * environment- Environment under which the automation is supposed to run
   * e.g. DEV, QA, PROD
   * customerIdentifier- 3 letter customer identifier e.g. mej,con..etc
   * @throws IOException 
   * @throws SecurityException 
   * 
   */

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  public String processAutomationAction(String payLoad) throws SecurityException, IOException
  {
    logger.info("Post method invoked");
    JsonParser parser = new JsonParser();
    JsonElement jsonRoot = parser.parse(payLoad);
    JsonObject jsonObject = jsonRoot.getAsJsonObject();
    Map<String, String> parameters = new HashMap<String, String>();
    Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();
    
    for (Map.Entry<String, JsonElement> entry : entries)
    {
      System.out.println("Entry key =" + entry.getKey());
      logger.info("Entry key ="+entry.getKey());
      String value = entry.getValue().getAsString().replace("\"", "");
      System.out.println("Entry Value =" + value);
      logger.info("Entry Value =" + value);
      parameters.put(entry.getKey(), value);
    }
     
    String action = parameters.get("action");
    String automationEngine = parameters.get("automationEngine");
    String automationName = parameters.get("automationName");
    String environment = parameters.get("environment");
    String customerIdentifier = parameters.get("customerIdentifier");
    
    System.out.println("action: " + action);
    System.out.println("automationEngine: " + automationEngine);
    System.out.println("automationName: " + automationName);
    System.out.println("environment: " + environment);
    System.out.println("customerIdentifier: " + customerIdentifier);
    System.out.println("Initial parameters: " + parameters);
    logger.info("Paramaters are" +action+automationEngine+automationName+environment+customerIdentifier);

    Iterator<Map.Entry<String, String>> iterator = parameters.entrySet().iterator();
    while (iterator.hasNext())
    {
      Map.Entry<String, String> entry = iterator.next();
      if ("action".equalsIgnoreCase(entry.getKey()) || "automationEngine".equalsIgnoreCase(entry.getKey())
          || "environment".equalsIgnoreCase(entry.getKey()) || "customerIdentifier".equalsIgnoreCase(entry.getKey()))
      {
        iterator.remove();
      }
    }
    
    if (action.equalsIgnoreCase("start"))
    {  
      System.out.println("parameters::" + parameters);
      logger.info("For start Automation");
      String runId = pluginManager.getPlugin(automationEngine).startAutomation(environment, customerIdentifier, parameters);
     return "{ \"runId\": " + "\"" + runId + "\"}";
    }
    else if (action.equalsIgnoreCase("status"))
    {
      logger.info("For status Automation");
      String status = pluginManager.getPlugin(automationEngine).getAutomationStatus(environment, customerIdentifier, parameters);
      return "{ \"status\": " + "\"" + status + "\"}";
    }
    return null;
  }
  
  /**
   * Fetches the path to the plugin directory from the configuration file.
   * 
   * @throws IOException
   */
  private Map<String, String> readProperties() throws IOException
  {
    Map<String, String> map = new HashMap<String, String>();
    
    try
    {
      Properties props = new Properties();
      FileReader fReader = null;
      fReader = new FileReader(CONFIGURATION_FILE_PATH);
      props.load(fReader);
      map.put("PATH_TO_PLUGIN_DIRECTORY", props.getProperty("PATH_TO_PLUGIN_DIRECTORY"));
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }  
    return map;
  }
}
