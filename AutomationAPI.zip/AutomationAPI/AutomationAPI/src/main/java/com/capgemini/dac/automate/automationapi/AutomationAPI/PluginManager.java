/*
*  Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate.automationapi.AutomationAPI;

import java.io.File;
import java.io.FileInputStream;

import java.lang.reflect.Constructor;

import java.net.URL;
import java.net.URLClassLoader;

import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.logging.Logger;


import com.capgemini.dac.automate.automationplugin.AutomationPlugin;

/**
* Manages plugin classes. The main method (loadPlugins) loads jars from a
* specific directory. It parses each jar for the class that implements the
* plugin. When it finds it, it automatically registers it in the plugin map.
* 
 * @author Hector Mendoza
*/
public class PluginManager
{
  
  private static Map<String, AutomationPlugin> pluginMap;
  private static final Logger logger = Logger.getLogger(PluginManager.class.getName());
  static PluginManager mySingleton_instance = null;
  /**
   * Default constructor. Instantiates attributes.
   */
  private PluginManager()
  {
  }

  /**
   * Gets the single instance of PluginManager.
   *
   * @param pathToPluginDir the path to plugin dir
   * @return single instance of PluginManager
   */
  public static PluginManager getInstance(String pathToPluginDir)
  {
    if (mySingleton_instance == null)
    {
      pluginMap = new HashMap<String, AutomationPlugin>();
      mySingleton_instance = new PluginManager();
      loadPlugins(pathToPluginDir);
    }
    return mySingleton_instance;
  }
  /**
   * For each jar file in the given plugin directory, it parses the jar in search
   * of a class that implements AutomationPlugin, it instantiates it and registers
   * it in pluginMap.
   *
   * @param pathToPluginDir Path to plugin directory containing jar files
   */
  public static void loadPlugins(String pathToPluginDir)
  {
    File pluginsDir = new File(pathToPluginDir);

    // for each jar file in plugin directory
    for (File jarFile : pluginsDir.listFiles())
    {
      JarInputStream jarInputStream = null;
      try
      {
        jarInputStream = new JarInputStream(new FileInputStream(jarFile));
        // parse the jar in search of class that implements AutomationPlugin
        JarEntry jarEntry = jarInputStream.getNextJarEntry();
        while (jarEntry != null)
        {
          if (jarEntry.getName().endsWith(".class"))
          {
            String rawEntryName = jarEntry.getName();
            // replace "/" in the path with "." to get complete class descriptor
            String classFileName = rawEntryName.replaceAll("/", "\\.");
            // get rid of .class in the name
            String className = classFileName.substring(0, classFileName.lastIndexOf('.'));
            ClassLoader loader = URLClassLoader.newInstance(new URL[] { jarFile.toURI().toURL() },  PluginManager.class.getClassLoader());
            Class<?> loadedClass = Class.forName(className, true, loader);            
            System.out.println("loadedClass:" + loadedClass);
            logger.info("loadedClass:" + loadedClass);

            // TODO: I tried to generalize the call to isAssignableFrom below
            // using template classes with no luck. If we can find a way to
            // generalize it, this plugin manager class can then be reused for
            // any plugin class
            // if class implements AutomationPlugin
            if (AutomationPlugin.class.isAssignableFrom(loadedClass))
            {
              System.out.println("This class implements automation plugin");
              logger.info("This class implements automation plugin");
              // instantiate class
              Constructor<?> constructor = loadedClass.getConstructor();
              AutomationPlugin pluginInstance = (AutomationPlugin) constructor.newInstance();
              String automationEngineName = pluginInstance.getAutomationEngineName();
              System.out.println("Automation Engine Name: " + automationEngineName);
              logger.info("Automation Engine Name: " + automationEngineName);
              // register in our plugin map
              pluginMap.put(automationEngineName, pluginInstance);
            }
            else
            {
              System.out.println("This class DOES NOT implement automation plugin");
              logger.info("This class DOES NOT implement automation plugin");
            }
          }
          // get next entry
          jarEntry = jarInputStream.getNextJarEntry();
        } // end of while (jarEntry != null)
      }
      catch (Exception e)
      {
        // there might be multiple JARs in the directory, so keep looking
        e.printStackTrace();
        logger.severe(e.getMessage());
        continue;
      }
      finally
      {
        try
        {
          jarInputStream.close();
        }
        catch (Exception e)
        {
          e.printStackTrace();
          logger.severe(e.getMessage());
        }
      }
    }
  }

  /**
   * Returns the plugin that corresponds to the given automation engine name.
   *
   * @param automationEngineName Automation engine name
   * @return Plugin that corresponds to given name
   */
  public AutomationPlugin getPlugin(String automationEngineName)
  {
    return pluginMap.get(automationEngineName);
  }
}
