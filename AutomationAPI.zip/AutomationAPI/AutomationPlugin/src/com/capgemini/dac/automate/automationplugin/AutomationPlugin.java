/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.automationplugin;

import java.util.Map;

/**
 * This class represents the contract for Automation Plugin developers. All
 * plugin implementation classes must implement this interface.
 * 
 * IMPORTANT: When using this JAR inside a Maven project, make sure you run the
 * following Maven command:
 * 
 * mvn install:install-file -Dfile=<path to exported JAR>
 * -DgroupId=com.capgemini.dac.automate.automationplugin
 * -DartifactId=automation-plugin -Dversion=1.0 -Dpackaging=jar
 * -DgeneratePom=true
 * 
 * This will install the library in your local Maven repo. Then include the
 * following dependency in your pom file:
 * 
 * <dependency>
 *   <groupId>com.capgemini.dac.automate.automationplugin</groupId>
 *   <artifactId>automation-plugin</artifactId>
 *   <version>1.0</version>
 * </dependency>
 * 
 * Note version numbers could change. The above is just an example.
 * 
 * @author Hector Mendoza
 */
public interface AutomationPlugin
{
  /**
   * This method shall return the name (or rather the key) of the automation
   * plugin you are implementing, e.g. "automic". This name will automatically
   * get registered in the PluginManager such that when an API call is received
   * (e.g. http://<API_URL>/automic/mej...) the web service knows how/who to
   * direct the call to.
   *
   * @return Name/key of automation engine plugin being implemented, e.g.
   * "automic"
   */
  public String getAutomationEngineName();

  /**
   * This method shall start the automation described by the given environment,
   * customer identifier, and parameters. It should also return the unique Run
   * ID that references this automation.
   *
   * @param environment Environment under which the automation is supposed to
   * run e.g. DEV, QA, PROD
   * @param customerIdentifier 3 letter customer identifier e.g. mej
   * @param parameters Map of key value pairs describing parameters for the
   * automation
   * @see Automation name should be part of parameters
   * @return The unique Run ID generated for the automation
   */
  public String startAutomation(String environment, String customerIdentifier, Map<String, String> parameters);

  /**
   * This method shall return the status of the automation that corresponds to
   * the given environment, customer identifier parameters.
   *
   * @param environment Environment under which the automation is supposed to
   * run e.g. DEV, QA, PROD
   * @param customerIdentifier 3 letter customer identifier
   * @param parameters Map of key value pairs describing parameters for the
   * automation
   * @see The unique Run ID should be part of parameters
   * @return Automation status e.g. RUNNING, COMPLETED, STOPPED, etc.
   */
  public String getAutomationStatus(String environment, String customerIdentifier, Map<String, String> parameters);
}
